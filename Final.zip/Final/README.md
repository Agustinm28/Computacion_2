# Final Computacion II
Repositorio para el final de computacion II.
Link del bot de Telegram: t.me/uppy28bot

<h2 style="color:blue;">Programa</h2>
Sistema de escalado de imagenes y videos a resoluciones mayores por interpolacion de pixeles.

<h2 style="color:#d9b3ff;">Diagrama y flujo de trabajo</h2>
<img src="assets/Diagram.jpeg" alt="Diagrama">